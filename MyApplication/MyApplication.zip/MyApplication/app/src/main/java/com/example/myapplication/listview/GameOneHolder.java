package com.example.myapplication.listview;

import android.widget.ImageView;
import android.widget.TextView;

public class GameOneHolder {
    TextView cardText;
    String hint;
    ImageView cardImg;
}
