package com.example.myapplication.listview;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

public class WordViewHolder {
    EditText editWordA;
    EditText editWordB;
    EditText editHint;
    ImageView wordImage;
    ImageButton wordImageBtn;
    int ref;
}
