package com.example.myapplication.listview;

public class GameTwoChatItem {

    private String user_id ;
    private String user_txt ;

    public void setUser_id(String id) {
        user_id = id ;
    }
    public void setUser_txt(String txt) {
        user_txt = txt ;
    }

    public String getUser_id() {
        return this.user_id ;
    }
    public String getUser_txt() {
        return this.user_txt ;
    }
}
